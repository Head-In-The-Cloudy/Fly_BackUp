#ifndef  _TJC_H_
#define  _TJC_H_


#include "main.h"
void Send_To_TJC(char* str);




#endif
