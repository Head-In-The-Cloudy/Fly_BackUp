#ifndef _ULTRA_H_
#define _ULTRA_H_

#include "main.h"

void trig(void);
void  get_len(void);


#endif 


