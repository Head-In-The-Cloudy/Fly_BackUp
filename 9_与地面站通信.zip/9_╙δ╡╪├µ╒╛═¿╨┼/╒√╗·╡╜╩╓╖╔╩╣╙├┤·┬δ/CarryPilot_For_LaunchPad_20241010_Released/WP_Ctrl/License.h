#ifndef __LICENSE_H_
#define __LICENSE_H_

void System_Start_Init(void);
void Copyright_Show(void);
void Resume_Factory_Setting(void);


#endif


