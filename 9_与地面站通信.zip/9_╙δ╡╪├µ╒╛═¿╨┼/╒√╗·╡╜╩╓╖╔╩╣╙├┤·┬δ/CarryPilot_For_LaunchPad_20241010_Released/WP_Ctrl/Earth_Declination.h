#ifndef EARTH_DECLINATION_H
#define EARTH_DECLINATION_H


float get_declination(float lat, float lon);


#endif


