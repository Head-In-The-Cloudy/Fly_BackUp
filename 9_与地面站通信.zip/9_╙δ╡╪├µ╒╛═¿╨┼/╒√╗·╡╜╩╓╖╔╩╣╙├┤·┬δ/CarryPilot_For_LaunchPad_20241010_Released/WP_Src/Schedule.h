#ifndef __SCHEDULE_H__
#define __SCHEDULE_H__

#include "WP_DataType.h"




void Test_Period(Testime *Time_Lab);
void Get_Systime(systime *sys);
	


#endif

