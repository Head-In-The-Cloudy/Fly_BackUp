#ifndef __SYSTEM_H_
#define __SYSTEM_H_

void HardWave_Init(void);
void NVIC_Configuration(void);
void WP_Init(void);
void nvic_priority_get(void);
#endif

