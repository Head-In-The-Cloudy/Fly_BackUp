#ifndef _OPTICALFLOW_LC306_H
#define _OPTICALFLOW_LC306_H

uint8_t Config_Init_Uart(void);

#endif


